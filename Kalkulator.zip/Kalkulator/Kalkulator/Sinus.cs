﻿using System;

namespace Kalkulator
{
    class Sinus : TrigonometricFunction
    {
        public override string CalculateOthers(double value)
        {
            double y = value;
            double r = 1;
            double x = Math.Sqrt(r * r - y * y);

            return $"Wartości wszystkich innych funkcji gdy wartość sinusa wynosi {value}:\n" +
                $"\tCos: {x / r}\n" +
                $"\tTg: {y / x}\n" +
                $"\tCtg: {x / y}";
        }

        public override string CalculateValueFromAngle(double angle)
        {
            return $"Wartość funkcji sinus o kącie {angle} rad wynosi: " + ((double)Math.Sin(angle)).ToString();
        }
        public override string CalculateValueFromCords(double x, double y)
        {
            double r = Math.Sqrt((x * x) + (y * y));
            return $"Wartość sinusa o podanych koordynatach: ({x},{y}), wynosi: " + (y / r).ToString();
        }
    }
}
