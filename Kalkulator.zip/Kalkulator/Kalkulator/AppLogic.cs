﻿using System;
// 1-sin, 2-cos, 3-tg, 4-ctg    ||||||||||      1-deg, 2-rad    ||||||||||      1-angtoval, 2-cords, 3-others
namespace Kalkulator
{
    public static partial class AppLogic
    {
        static ConsoleKeyInfo cki;
        public static int workmode;
        public static int operation;
        public static int usedFunction;
        public static void ChooseUnit()
        {
            Console.WriteLine("Jeśli chcesz pracować w Stopniach kliknij 1, jeśli w Radianach kliknij 2.");
            do
            {
                cki = Console.ReadKey(true);
                if (cki.Key == ConsoleKey.D1)
                    workmode = 1;
                else if (cki.Key == ConsoleKey.D2)
                    workmode = 2;
                else
                {
                    Console.WriteLine("Błąd! Podaj jednostkę jeszcze raz.");
                }
            } while (cki.Key != ConsoleKey.D1 && cki.Key != ConsoleKey.D2);
        }
        public static void ChooseOperation()
        {
            Console.WriteLine("Działania z jakich możesz skorzystać:\n" +
                "\tOblicz wartość na podstawie miary kąta - 1\n" +
                "\tOblicz wartość i kąt na podstawie współrzędnych w okresie (punkt końcowy 2 ramienia) - 2\n" +
                "\tOblicz wartość innych funkcji trygonometrycznych, na podstawie wartości jednej z nich - 3");

            do
            {
                cki = Console.ReadKey(true);
                if (cki.Key == ConsoleKey.D1)
                    operation = 1;
                else if (cki.Key == ConsoleKey.D2)
                    operation = 2;
                else if (cki.Key == ConsoleKey.D3)
                    operation = 3;
                else
                {
                    Console.WriteLine("Błąd! Podaj, które działanie chcesz wykonać jeszcze raz.");
                }
            } while (cki.Key != ConsoleKey.D1 &&
            cki.Key != ConsoleKey.D2 &&
            cki.Key != ConsoleKey.D3);
        }
        public static void ChooseWhichTrgFunction()
        {
            if (operation == 1)
            {
                Console.WriteLine("Dla jakiej funkcji trygonometrycznej chcesz wykonać to działanie?\n" +
                        "\tSinus - 1\n" +
                        "\tCosinus - 2\n" +
                        "\tTangens - 3\n" +
                        "\tCotangens - 4\n" +
                        "\tWszystkich - 5");
                do
                {
                    cki = Console.ReadKey(true);
                    if (cki.Key == ConsoleKey.D1)
                        usedFunction = 1;
                    else if (cki.Key == ConsoleKey.D2)
                        usedFunction = 2;
                    else if (cki.Key == ConsoleKey.D3)
                        usedFunction = 3;
                    else if (cki.Key == ConsoleKey.D4)
                        usedFunction = 4;
                    else if (cki.Key == ConsoleKey.D5)
                        usedFunction = 5;
                    else
                    {
                        Console.WriteLine("Błąd! Podaj, które działanie chcesz wykonać jeszcze raz.");
                    }
                } while (cki.Key != ConsoleKey.D1 &&
                            cki.Key != ConsoleKey.D2 &&
                            cki.Key != ConsoleKey.D3 &&
                            cki.Key != ConsoleKey.D4 &&
                            cki.Key != ConsoleKey.D5);
            }
            else
            {
                Console.WriteLine("Dla jakiej funkcji trygonometrycznej chcesz wykonać to działanie?\n" +
                        "\tSinus - 1\n" +
                        "\tCosinus - 2\n" +
                        "\tTangens - 3\n" +
                        "\tCotangens - 4");

                do
                {
                    cki = Console.ReadKey(true);
                    if (cki.Key == ConsoleKey.D1)
                        usedFunction = 1;
                    else if (cki.Key == ConsoleKey.D2)
                        usedFunction = 2;
                    else if (cki.Key == ConsoleKey.D3)
                        usedFunction = 3;
                    else if (cki.Key == ConsoleKey.D4)
                        usedFunction = 4;
                    else
                    {
                        Console.WriteLine("Błąd! Podaj, które działanie chcesz wykonać jeszcze raz.");
                    }
                } while (cki.Key != ConsoleKey.D1 &&
                            cki.Key != ConsoleKey.D2 &&
                            cki.Key != ConsoleKey.D3 &&
                            cki.Key != ConsoleKey.D4);
            }
        }
        static void AskIfContinue()
        {
            Console.WriteLine("Jeśli chcesz kontynuowac obliczenia kliknij Enter\n,aby zakończyć kliknij dowolny inny przycisk");
        }
        public static bool ContinueOrNot()
        {
            AskIfContinue();
            if (Console.ReadKey(true).Key == ConsoleKey.Enter)
                return true;
            else
                return false;
        }
    }
}
