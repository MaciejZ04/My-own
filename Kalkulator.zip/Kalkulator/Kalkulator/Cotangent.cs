﻿using System;

namespace Kalkulator
{
    class Cotangent : TrigonometricFunction
    {
        public override string CalculateOthers(double value)
        {
            double x = value;
            double y = 1;
            double r = Math.Sqrt(y * y + x * x);

            return $"Wartości wszystkich innych funkcji gdy wartość cotangensa wynosi {value}:\n" +
                $"\tSin: {y / r}\n" +
                $"\tCos: {x / r}\n" +
                $"\tTg: {y / x}";
        }

        public override string CalculateValueFromAngle(double angle)
        {
            return $"Wartość funkcji cotangens o kącie {angle} rad wynosi: " + ((double)(1/Math.Tan(angle))).ToString();
        }
        public override string CalculateValueFromCords(double x, double y)
        {
            if (y != 0)
            {
                return $"Wartość cotangensa o podanych koordynatach: ({x},{y}), wynosi: " + (x / y).ToString();
            }
            else
            {
                return "Taki cotangens nie istnieje";
            }
            
        }
    }
}
