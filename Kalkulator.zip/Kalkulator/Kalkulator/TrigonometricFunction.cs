﻿using System;
using System.Data;

namespace Kalkulator
{
    abstract class TrigonometricFunction
    {
        public double Angle { get; set; }
        public double Value { get; set; }

        public abstract string CalculateOthers(double value);
        public abstract string CalculateValueFromAngle(double angle);
        public abstract string CalculateValueFromCords(double x, double y);
    }
}
