﻿using System;
using static Kalkulator.AppLogic;

namespace Kalkulator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Witaj w kalkulatorze funkcji trygonometrycznych!"); 
            ChooseUnit();
            do
            {
                Console.WriteLine();

                ChooseOperation();

                Console.WriteLine();

                ChooseWhichTrgFunction();

                Console.WriteLine();

                //calculations
                DoCalculations(workmode,operation,usedFunction);
                //end of calculations

                Console.WriteLine();
            }while (ContinueOrNot()); 
        }
    }
}
