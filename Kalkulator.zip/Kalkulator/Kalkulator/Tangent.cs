﻿using System;
using System.Data;

namespace Kalkulator
{
    class Tangent : TrigonometricFunction
    {
        public override string CalculateOthers(double value)
        {
            double y = value;
            double x = 1.0;
            double r = Math.Sqrt(y * y + x * x);

            return $"Wartości wszystkich innych funkcji gdy wartość tangensa wynosi {value}:\n" +
                $"\tSin: {y/r}\n" +
                $"\tCos: {x/r}\n" +
                $"\tCtg: {x/y}";
        }

        

        public override string CalculateValueFromAngle(double angle)
        {
            return $"Wartość funkcji tangens o kącie {angle} rad wynosi: " + ((double)Math.Tan(angle)).ToString();
        }
        public override string CalculateValueFromCords(double x, double y)
        {
            if (y != 0)
            {
                return $"Wartość tangensa o podanych koordynatach: ({x},{y}), wynosi: " + (y / x).ToString();
            }
            else
            {
                return "Taki tangens nie istnieje";
            }
        }
    }
}
