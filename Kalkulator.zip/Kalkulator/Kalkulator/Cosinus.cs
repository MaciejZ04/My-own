﻿using System;

namespace Kalkulator
{
    class Cosinus : TrigonometricFunction
    {
        public override string CalculateOthers(double value)
        {
            double x = value;
            double r = 1;
            double y = Math.Sqrt(r * r - x * x);

            return $"Wartości wszystkich innych funkcji gdy wartość sinusa wynosi {value}:\n" +
                $"\tSin: {y / r}\n" +
                $"\tTg: {y / x}\n" +
                $"\tCtg: {x / y}";
        }

        public override string CalculateValueFromAngle(double angle)
        {
            return $"Wartość funkcji cosinus o kącie {angle} rad wynosi: " + ((double)Math.Cos(angle)).ToString();
        }
        public override string CalculateValueFromCords(double x, double y)
        {
            double r = Math.Sqrt((x * x) + (y * y));
            return $"Wartość cosinusa o podanych koordynatach: ({x},{y}), wynosi: " + (x / r).ToString();
        }
    }
}
