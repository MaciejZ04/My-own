﻿using System;
using System.IO;


namespace Kalkulator
// 1-sin, 2-cos, 3-tg, 4-ctg    ||||||||||      1-deg, 2-rad    ||||||||||      1-angtoval, 2-cords, 3-others
{
    public static partial class AppLogic
    {
        public static double ConvertToRads(double angle)
        {
            angle = Math.Round(angle * (Math.PI / 180), 6);
            return angle;
        }
        public static double[] GetParametersForOperation(int operation)
        {          
            if (operation == 1)
            {
                Console.WriteLine("Podaj miarę kąta:");
                double angle = double.Parse(Console.ReadLine());
                double[] result = { angle };
                return result;
            }
            else if (operation == 2)
            {
                Console.WriteLine("Podaj współrzędną X:");
                double x = double.Parse(Console.ReadLine());
                Console.WriteLine("Podaj współrzędną Y:");
                double y = double.Parse(Console.ReadLine());
                double[] result = { x, y };
                return result;
            }
            else if (operation == 3)
            {
                Console.WriteLine("Podaj wartość znanej Ci funkcji:");
                double fun = double.Parse(Console.ReadLine());
                double[] result = { fun };
                return result;
            }
            else
            {
                double[] result = { 0.0 };
                return result;
            }    
        }
        public static void DoCalculations(int workmode, int operation, int usedFunction)
        {

            //zapis historii do pliku
            using StreamWriter file = new StreamWriter("History.txt", true);


            if (usedFunction == 1)
            {
                Sinus sin = new Sinus();

                if (operation == 1)
                {
                    double angle = GetParametersForOperation(operation)[0];
                    switch (workmode)
                    {
                        case 1:
                            Console.WriteLine(sin.CalculateValueFromAngle(ConvertToRads(angle)));
                            file.WriteLine(sin.CalculateValueFromAngle(ConvertToRads(angle)));
                            break;
                        case 2:
                            Console.WriteLine(sin.CalculateValueFromAngle(angle));
                            file.WriteLine(sin.CalculateValueFromAngle(angle));
                            break;
                    }
                    
                }
                else if (operation == 2)
                {
                    double[] results = GetParametersForOperation(operation);
                    double x = results[0];
                    double y = results[1];
                    Console.WriteLine(sin.CalculateValueFromCords(x,y));
                    file.WriteLine(sin.CalculateValueFromCords(x,y));
                }
                if (operation == 3)
                {
                    double value = GetParametersForOperation(operation)[0];
                    Console.WriteLine(sin.CalculateOthers(value));
                    file.WriteLine(sin.CalculateOthers(value));
                }
                
                
            }
            else if (usedFunction == 2)
            {
                Cosinus cos = new Cosinus();
                if (operation == 1)
                {
                    double angle = GetParametersForOperation(operation)[0];
                    switch (workmode)
                    {
                        case 1:
                            Console.WriteLine(cos.CalculateValueFromAngle(ConvertToRads(angle)));
                            file.WriteLine(cos.CalculateValueFromAngle(ConvertToRads(angle)));
                            break;
                        case 2:
                            Console.WriteLine(cos.CalculateValueFromAngle(angle));
                            file.WriteLine(cos.CalculateValueFromAngle(angle));
                            break;
                    }

                }
                else if (operation == 2)
                {
                    double[] results = GetParametersForOperation(operation);
                    double x = results[0];
                    double y = results[1];
                    Console.WriteLine(cos.CalculateValueFromCords(x, y));
                    file.WriteLine(cos.CalculateValueFromCords(x, y));
                }
                if (operation == 3)
                {
                    double value = GetParametersForOperation(operation)[0];
                    Console.WriteLine(cos.CalculateOthers(value));
                    file.WriteLine(cos.CalculateOthers(value));
                }
            }
            else if (usedFunction == 3)
            {
                Tangent tg = new Tangent();
                if (operation == 1)
                {
                    double angle = GetParametersForOperation(operation)[0];
                    switch (workmode)
                    {
                        case 1:
                            Console.WriteLine(tg.CalculateValueFromAngle(ConvertToRads(angle)));
                            file.WriteLine(tg.CalculateValueFromAngle(ConvertToRads(angle)));
                            break;
                        case 2:
                            Console.WriteLine(tg.CalculateValueFromAngle(angle));
                            file.WriteLine(tg.CalculateValueFromAngle(angle));
                            break;
                    }

                }
                else if (operation == 2)
                {
                    double[] results = GetParametersForOperation(operation);
                    double x = results[0];
                    double y = results[1];
                    Console.WriteLine(tg.CalculateValueFromCords(x, y));
                    file.WriteLine(tg.CalculateValueFromCords(x, y));
                }
                if (operation == 3)
                {
                    double value = GetParametersForOperation(operation)[0];
                    Console.WriteLine(tg.CalculateOthers(value));
                    file.WriteLine(tg.CalculateOthers(value));
                }
            }
            else if (usedFunction == 4)
            {
                Cotangent ctg = new Cotangent();
                if (operation == 1)
                {
                    double angle = GetParametersForOperation(operation)[0];
                    switch (workmode)
                    {
                        case 1:
                            Console.WriteLine(ctg.CalculateValueFromAngle(ConvertToRads(angle)));
                            file.WriteLine(ctg.CalculateValueFromAngle(ConvertToRads(angle)));
                            break;
                        case 2:
                            Console.WriteLine(ctg.CalculateValueFromAngle(angle));
                            file.WriteLine(ctg.CalculateValueFromAngle(angle));
                            break;
                    }

                }
                else if (operation == 2)
                {
                    double[] results = GetParametersForOperation(operation);
                    double x = results[0];
                    double y = results[1];
                    Console.WriteLine(ctg.CalculateValueFromCords(x, y));
                    file.WriteLine(ctg.CalculateValueFromCords(x, y));
                }
                if (operation == 3)
                {
                    double value = GetParametersForOperation(operation)[0];
                    Console.WriteLine(ctg.CalculateOthers(value));
                    file.WriteLine(ctg.CalculateOthers(value));
                }
            }
            else if (usedFunction == 5)
            {
                Sinus sin = new Sinus();
                Cosinus cos = new Cosinus();
                Tangent tg = new Tangent();
                Cotangent ctg = new Cotangent();
                double angle = GetParametersForOperation(operation)[0];
                switch (workmode)
                {
                    case 1:
                        Console.WriteLine(sin.CalculateValueFromAngle(ConvertToRads(angle)));
                        file.WriteLine(sin.CalculateValueFromAngle(ConvertToRads(angle)));
                        Console.WriteLine(cos.CalculateValueFromAngle(ConvertToRads(angle)));
                        file.WriteLine(cos.CalculateValueFromAngle(ConvertToRads(angle)));
                        Console.WriteLine(tg.CalculateValueFromAngle(ConvertToRads(angle)));
                        file.WriteLine(tg.CalculateValueFromAngle(ConvertToRads(angle)));
                        Console.WriteLine(ctg.CalculateValueFromAngle(ConvertToRads(angle)));
                        file.WriteLine(ctg.CalculateValueFromAngle(ConvertToRads(angle)));
                        break;
                    case 2:
                        Console.WriteLine(sin.CalculateValueFromAngle(angle));
                        file.WriteLine(sin.CalculateValueFromAngle(angle));
                        Console.WriteLine(cos.CalculateValueFromAngle(angle));
                        file.WriteLine(cos.CalculateValueFromAngle(angle));
                        Console.WriteLine(tg.CalculateValueFromAngle(angle));
                        file.WriteLine(tg.CalculateValueFromAngle(angle));
                        Console.WriteLine(ctg.CalculateValueFromAngle(angle));
                        file.WriteLine(ctg.CalculateValueFromAngle(angle));
                        break;
                }
            }
            else
            {
                Console.WriteLine("Niepoprawna funkcja trygonometryczna, wybierz jeszcze raz.");
                ChooseWhichTrgFunction();
            }       
        }
    }
}
